create definer = root@`%` trigger after_article_delete
    after delete
    on article
    for each row
BEGIN
    DELETE FROM article_tag WHERE article_tag.article_id = OLD.id;
END;

